function AboutUs() {
  return (
    <div className="p-4 mb-3 mx-5">
      <div style={{ textAlign: "center" }}>
        <h1>About Us</h1>
      </div>
      <p>
        Plan your wedding with Us. Lagna Ghar is your personal wedding planning
        site. Browse through the site to find vendors for your wedding. Explore
        wedding inspiration & ideas to prepare for your wedding following latest
        trends.
      </p>
      <p>We are the Team of Four</p>
      <p>Gaurav Tiwary</p>
      <p>Hitesh Yewale</p>
      <p>Manali Toshniwal</p>
      <p>Madhav Wakhare</p>
    </div>
  );
}
export default AboutUs;
