export const constants = {
    serverUrl : "http://localhost:8080/Project"
}