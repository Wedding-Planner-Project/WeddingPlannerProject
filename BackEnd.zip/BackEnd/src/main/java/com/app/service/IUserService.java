package com.app.service;

import com.app.dto.UserDto;

public interface IUserService {
	public UserDto authUser(UserDto userdto);
}
