package com.app.model;

public enum Role {
ROLE_ADMIN, ROLE_VENDOR, ROLE_CUSTOMER
}
