package com.app.model;

public enum Read {
READ,UNREAD
}
