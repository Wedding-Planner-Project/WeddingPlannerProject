package com.app.model;

public enum Rating {
POOR,AVERAGE,GOOD,VERYGOOD, EXCELLENT
}
