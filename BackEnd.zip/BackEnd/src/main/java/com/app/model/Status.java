package com.app.model;

public enum Status {
PENDING, COMPLETED
}
