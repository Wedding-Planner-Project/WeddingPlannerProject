package com.app.service;

import com.app.dto.BehaviourDto;

public interface IBehaviourService {

	String addBehaviour(String cid, Integer sid);
}
