package com.app.service;

import java.util.List;

import com.app.dto.ServicesDto;
import com.app.dto.VendorDto;
import com.app.model.ServiceDetails;

public interface IVendorService {

	String addVendor(VendorDto vendordto);

	String deleteVendor(String vemail);

	List<VendorDto> getAllVendors();

	String addService(ServicesDto ser, String email);

	List<ServiceDetails> getServices(String vemail);

	String updateService(ServicesDto ser, String email);

	String updateProfile(VendorDto vdto, String vemail);

	String deleteProfile(String vemail);

	VendorDto getVProfile(String vemail);
	
}
