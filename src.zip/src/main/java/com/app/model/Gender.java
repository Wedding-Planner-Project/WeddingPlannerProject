package com.app.model;

public enum Gender {
MALE,FEMALE,OTHER
}
