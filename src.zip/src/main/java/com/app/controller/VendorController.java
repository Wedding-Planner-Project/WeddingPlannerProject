package com.app.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.MailBoxDto;
import com.app.dto.OrdersDto;
import com.app.dto.ServicesDto;
import com.app.dto.VendorDto;
import com.app.model.ServiceDetails;
import com.app.model.Users;
import com.app.service.IMailService;
import com.app.service.IOrderService;
import com.app.service.IVendorService;


@CrossOrigin
@RestController
@RequestMapping("/vendor")
public class VendorController {
	
	@Autowired
	IVendorService vendorService;
	
	@Autowired
	IMailService mailService;
	
	@Autowired
	IOrderService orderService;
	
	//1. add service
	@PostMapping("/addservice/{vemail}")
	public String addService(@RequestBody ServicesDto ser, @PathVariable String vemail) {
		String mesg = vendorService.addService(ser, vemail);
		return mesg;
	}
	
	//2.  view Service
	@GetMapping("/services/{vemail}")
	public List<ServicesDto> getServices(@PathVariable String vemail){
		List<ServiceDetails> services = vendorService.getServices(vemail);
		List<ServicesDto> allServices = new ArrayList<ServicesDto>();
		services.forEach(s->allServices.add(new ServicesDto(s.getService().getServName(),
											s.getServ_desc(),s.getServ_price(),
											s.getCreatn_date(),s.getMod_date())));
		return allServices;
	}
	//3. update service
	@PostMapping("/updateService/{vemail}")
	public String updateService(@RequestBody ServicesDto ser, @PathVariable String vemail) {
		String mesg = vendorService.updateService(ser,vemail);
		
		return mesg;
	}
	
	//4. update profile
	@PutMapping("/profile/{vemail}")
	public String updateProfile(@RequestBody VendorDto vdto, @PathVariable String vemail) {
		String mesg = vendorService.updateProfile(vdto, vemail);
		
		return mesg;
	}
	
	//5. delete profile
	@DeleteMapping("/profile/{vemail}")
	public String deleteProfile(@PathVariable String vemail) {
		String mesg = vendorService.deleteProfile(vemail);
		
		return mesg;	
	}
	//6. view orders
	@GetMapping("/orders/{vemail}")
	public List<OrdersDto> getVendOrders(@PathVariable String vemail){
		List<OrdersDto> orders = orderService.getVendorOrders(vemail);
		
		return orders;
	}
	//7. cancel orders
	@DeleteMapping("/orders/{oid}")
	public String cancelOrder(@PathVariable Integer oid) {
		String mesg = orderService.deleteOrder(oid);
		return mesg;
	}
	
	
	//8. change  status of orders to completed
	@PutMapping("/orders/{oid}")
	public String updateOrderStatus(@PathVariable Integer oid) {
		String mesg = orderService.updateOrderStatus(oid);
		
		return mesg;
	}
	
	//9. send message
	@PostMapping("/mail/{uemail}")
	public String sendMessage(@RequestBody MailBoxDto mail, @PathVariable String uemail) {
		String mesg = mailService.sendMessage(mail, uemail);
		
		return mesg;
	}
	
	//10. get Messages
	@GetMapping("/mail/{vemail}")
	public Set<MailBoxDto> receiveMessages(@PathVariable String vemail){
		Set<MailBoxDto> messages = mailService.getVMessages(vemail);
		return messages;
	}
	
	//11. get vendor profile
	@GetMapping("/profile/{vemail}")
	public VendorDto getVendorProfile(@PathVariable String vemail) {
		VendorDto vendor = vendorService.getVProfile(vemail);
		
		return vendor;
	}
	
	//12. get Vendor chats
	@GetMapping("/chats/{vemail}")
	public Set<String> getVendorChats(@PathVariable String vemail){
		Set<String> chats = mailService.getVendorChats(vemail);
		
		return chats;
	}
	
	//13. get Vendor-customer pair chats
	@GetMapping("/messages/{cemail}/{vemail}")
	public Set<MailBoxDto> getCVChats(@PathVariable String cemail, @PathVariable String vemail){
		Set<MailBoxDto> messages = mailService.getCandVChats(cemail,vemail);
		
		return messages;
	}
}
